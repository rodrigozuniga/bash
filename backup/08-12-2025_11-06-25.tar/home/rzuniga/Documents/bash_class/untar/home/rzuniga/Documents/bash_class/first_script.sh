#!/bin/bash
#hash and bang = shbang

echo "this  is my first script"

exit 10

#exit command defines the value of the exit variable
#to get the exit value: echo $?
